describe("Just check if test setup is working", () => {
  test("works?", () => {
    console.log("Yes it works!");
  });
});

export {};
