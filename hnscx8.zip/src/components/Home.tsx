import React from "react";

export class Home extends React.Component {
  render() {
    return <div>Welcome ti the home page!</div>;
  }
}
